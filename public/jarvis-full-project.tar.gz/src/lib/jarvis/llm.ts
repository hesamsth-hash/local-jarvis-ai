// Local LLM bridge — connects the console to on-device model servers.
// Supported: Ollama (native API) and any OpenAI-compatible server
// (KoboldCpp, LM Studio, llama.cpp server, text-generation-webui...).
// Everything stays on the machine: these are localhost HTTP endpoints.

import { memoryPromptBlock } from "./memory";

export type LlmProviderKind = "ollama" | "openai-compatible" | "pollinations";

export interface LlmConfig {
  enabled: boolean;
  provider: LlmProviderKind;
  url: string; // e.g. http://localhost:11434 (ollama) or http://localhost:5001
  model: string;
  /** Vision model for See & Act (e.g. llava, llama3.2-vision, qwen2-vl). Optional. */
  visionModel?: string;
  /** API key for cloud OpenAI-compatible endpoints (Fireworks, Groq, OpenRouter…). */
  apiKey?: string;
  /** Which preset chip is active (for the UI hint line). */
  presetId?: string;
}

// Default brain = keyless cloud (Pollinations): zero setup, works instantly.
// Users who want 100% offline can switch to Ollama/Kobold in the Brain tab.
export const DEFAULT_LLM_CONFIG: LlmConfig = {
  enabled: true,
  provider: "pollinations",
  url: "https://text.pollinations.ai",
  model: "",
  visionModel: "",
  apiKey: "",
  presetId: "pollinations",
};

export const PRESETS: {
  id: string;
  label: string;
  provider: LlmProviderKind;
  url: string;
  hint: string;
  /** Cloud endpoint — needs an API key instead of a local server. */
  cloud?: boolean;
  /** Cloud endpoint that needs NO key and NO signup at all. */
  keyless?: boolean;
}[] = [
  // ---- Keyless: no key, no account, straight to work ----
  {
    id: "pollinations",
    label: "Pollinations ✨ keyless",
    provider: "pollinations",
    url: "https://text.pollinations.ai",
    hint: "no key, no signup — free community AI (rate-limited). Zero setup: pick it and go.",
    cloud: true,
    keyless: true,
  },
  {
    id: "llm7",
    label: "LLM7.io ✨ keyless",
    provider: "openai-compatible",
    url: "https://api.llm7.io/v1",
    hint: "no key, no signup — anonymous tier 10 req/min · 60/hr (gpt-oss:20b, mistral-nemo, minimax…)",
    cloud: true,
    keyless: true,
  },
  {
    id: "kilo",
    label: "Kilo Code ✨ keyless",
    provider: "openai-compatible",
    url: "https://api.kilo.ai/api/gateway",
    hint: "free model pool, NO key — 200 req/hr. Try model: openrouter/free or nvidia/nemotron-3-super-120b-a12b:free",
    cloud: true,
    keyless: true,
  },
  {
    id: "ovh",
    label: "OVHcloud ✨ keyless",
    provider: "openai-compatible",
    url: "https://oai.endpoints.kepler.ai.cloud.ovh.net/v1",
    hint: "EU-hosted, no key, no signup — 2 req/min per model (gpt-oss-120b, Qwen3, Llama-3.3-70B…)",
    cloud: true,
    keyless: true,
  },
  {
    id: "keylessai",
    label: "KeylessAI ✨ keyless",
    provider: "openai-compatible",
    url: "https://keylessai.thryx.workers.dev/v1",
    hint: "free OpenAI-compatible endpoint, no key — if it's down, paste the current /v1 URL from their npm page (search \"keylessai npm\") into the address field",
    cloud: true,
    keyless: true,
  },
  // ---- Local servers: 100% offline ----
  {
    id: "ollama",
    label: "Ollama",
    provider: "ollama",
    url: "http://localhost:11434",
    hint: "ollama serve  (default port 11434)",
  },
  {
    id: "koboldcpp",
    label: "KoboldCpp",
    provider: "openai-compatible",
    url: "http://localhost:5001",
    hint: "launch KoboldCpp — OpenAI-compatible API on port 5001",
  },
  {
    id: "lmstudio",
    label: "LM Studio",
    provider: "openai-compatible",
    url: "http://localhost:1234",
    hint: "LM Studio → Local Server (port 1234)",
  },
  {
    id: "llamacpp",
    label: "llama.cpp server",
    provider: "openai-compatible",
    url: "http://localhost:8080",
    hint: "llama-server --port 8080",
  },
  {
    id: "omniroute",
    label: "OmniRoute gateway",
    provider: "openai-compatible",
    url: "http://localhost:20128/v1",
    hint: "run OmniRoute locally (open-source AI gateway) — it pools your AI accounts into one local OpenAI-compatible endpoint",
  },
  {
    id: "freellmapi",
    label: "FreeLLMAPI 🔀 gateway",
    provider: "openai-compatible",
    url: "http://localhost:3001/v1",
    hint: "self-hosted router (tashfeenahmed/freellmapi) — stacks 34 free provider tiers (~7.4B tokens/mo) behind one endpoint. Install: freellmapi.co → add keys on its dashboard → paste its unified key below",
    cloud: true,
  },
  // ---- Keyed cloud: free tiers with a key ----
  {
    id: "openrouter",
    label: "OpenRouter ☁ cloud",
    provider: "openai-compatible",
    url: "https://openrouter.ai/api/v1",
    hint: "one key, 200+ models incl. free GLM/DeepSeek (ids ending in :free) — key from openrouter.ai/keys",
    cloud: true,
  },
  {
    id: "groq",
    label: "Groq ⚡ cloud",
    provider: "openai-compatible",
    url: "https://api.groq.com/openai/v1",
    hint: "paste your Groq API key below — free tier, extremely fast",
    cloud: true,
  },
  {
    id: "fireworks",
    label: "Fireworks ⚡ cloud",
    provider: "openai-compatible",
    url: "https://api.fireworks.ai/inference/v1",
    hint: "paste your Fireworks API key below — fastest hosted open-source models",
    cloud: true,
  },
];

export interface ModelInfo {
  id: string;
  size?: string;
}

async function fetchJson(url: string, init?: RequestInit, timeoutMs = 8000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: ctrl.signal });
    if (!res.ok) {
      throw new Error(`HTTP ${res.status} from ${url}`);
    }
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

export function normalizeUrl(url: string): string {
  return url.replace(/\/+$/, "");
}

/** Base without a trailing /v1 so we can append /v1/... exactly once. */
function apiBase(url: string): string {
  return normalizeUrl(url).replace(/\/v1$/, "");
}

/** Bearer auth header for cloud OpenAI-compatible endpoints. */
function authHeaders(cfg: LlmConfig): Record<string, string> {
  return cfg.apiKey?.trim() ? { Authorization: `Bearer ${cfg.apiKey.trim()}` } : {};
}

/** Ping the configured server; returns true if reachable. */
export async function testConnection(cfg: LlmConfig): Promise<boolean> {
  try {
    if (cfg.provider === "ollama") {
      await fetchJson(`${normalizeUrl(cfg.url)}/api/tags`, { headers: authHeaders(cfg) }, 4000);
    } else if (cfg.provider === "pollinations") {
      await fetchJson(`${normalizeUrl(cfg.url)}/models`, undefined, 6000);
    } else {
      try {
        await fetchJson(`${apiBase(cfg.url)}/v1/models`, { headers: authHeaders(cfg) }, 4000);
      } catch {
        // Some gateways serve the catalog without the /v1 prefix (Kilo…).
        await fetchJson(`${normalizeUrl(cfg.url)}/models`, { headers: authHeaders(cfg) }, 4000);
      }
    }
    return true;
  } catch {
    return false;
  }
}

/** List models available on the server. */
export async function listModels(cfg: LlmConfig): Promise<ModelInfo[]> {
  if (cfg.provider === "pollinations") {
    const data = await fetchJson(`${normalizeUrl(cfg.url)}/models`);
    const raw = (data as unknown) ?? [];
    // Shape has varied over time: ["openai", ...] or [{name/ id, description?}]
    const arr = Array.isArray(raw) ? raw : [];
    return arr
      .map((m) => {
        if (typeof m === "string") return { id: m };
        const o = m as { name?: string; id?: string; description?: string };
        const id = o.name ?? o.id;
        return id ? { id, size: o.description?.slice(0, 40) } : null;
      })
      .filter((m): m is ModelInfo => m !== null);
  }
  if (cfg.provider === "ollama") {
    const data = await fetchJson(`${normalizeUrl(cfg.url)}/api/tags`, { headers: authHeaders(cfg) });
    const models = (data as { models?: { name: string; size?: number }[] })
      .models ?? [];
    return models.map((m) => ({
      id: m.name,
      size: m.size ? `${(m.size / 1e9).toFixed(1)} GB` : undefined,
    }));
  }
  try {
    const data = await fetchJson(`${apiBase(cfg.url)}/v1/models`, { headers: authHeaders(cfg) });
    const models = (data as { data?: { id: string }[] }).data ?? [];
    return models.map((m) => ({ id: m.id }));
  } catch {
    // Some gateways serve /models without the /v1 prefix (Kilo, others) —
    // tolerate both shapes before giving up.
    const data = await fetchJson(`${normalizeUrl(cfg.url)}/models`, { headers: authHeaders(cfg) });
    const raw = (data as unknown) ?? [];
    const arr: unknown[] = Array.isArray(raw)
      ? raw
      : ((raw as { data?: unknown[]; models?: unknown[] }).data ??
        (raw as { models?: unknown[] }).models ??
        []);
    return arr
      .map((m) => {
        if (typeof m === "string") return { id: m };
        const o = m as { id?: string; name?: string };
        const id = o.id ?? o.name;
        return id ? { id } : null;
      })
      .filter((m): m is ModelInfo => m !== null);
  }
}

const SYSTEM_PROMPT = `You are JARVIS, a local personal assistant running on the user's own machine.
You control tools on the user's device. Be concise and helpful (2-4 sentences unless asked for more).
When a task matches one of your tools, reply with EXACTLY one JSON object and nothing else:
{"tool":"<tool_id>","args":{...}}
Available tools and their args:
{TOOLS}{MEMORY}
After the JSON you will receive a tool result as a user message starting with [TOOL_RESULT]; then answer the user in plain text using that result.
If no tool is needed, just answer in plain text.

SELF-EXTENSION: if the user asks for something NO existing tool can do, and it can be done with a fetch/open/notify, do NOT refuse and do NOT say you lack the capability — instead create the tool right now by replying with a make_tool JSON call. Write compact sandboxed JS; the code is the body of async (args, jv) and must return the result string. Use jv.fetchJson/jv.fetchText/jv.open/jv.notify. After installing, tell the user the tool is ready. If the task needs a real program that is not installed (desktop), you may offer install_tool with the right winget package id.

MEMORY: you have a persistent memory via the remember / list_memory / forget tools. When the user shares a durable personal fact (name, preferences, projects, devices, schedules), save it with remember. Use remembered facts naturally in answers — it makes you feel like you actually know them.`;

export interface LlmMessage {
  role: "system" | "user" | "assistant";
  content: string;
  /** Ollama-style images: raw base64 (no data: prefix). */
  images?: string[];
  /** OpenAI-style multimodal content parts (used when images present on openai-compatible). */
  contentParts?: {
    type: "text" | "image_url";
    text?: string;
    image_url?: { url: string };
  }[];
}

export interface ToolSpec {
  id: string;
  description: string;
  args?: string; // JSON example of args
}

interface ChatOptions {
  temperature?: number;
  maxTokens?: number;
  signal?: AbortSignal;
}

/** One completion against the local server. */
export async function llmChat(
  cfg: LlmConfig,
  messages: LlmMessage[],
  opts: ChatOptions = {},
): Promise<string> {
  const url = normalizeUrl(cfg.url);
  if (cfg.provider === "pollinations") {
    // Keyless OpenAI-compatible endpoint (POST /openai, no /v1 prefix).
    const data = await fetchJson(`${url}/openai`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders(cfg) },
      body: JSON.stringify({
        model: cfg.model || "openai",
        messages,
        temperature: opts.temperature ?? 0.4,
        max_tokens: opts.maxTokens ?? 400,
        stream: false,
      }),
    }, 120000);
    const content = (data as {
      choices?: { message?: { content?: string } }[];
    }).choices?.[0]?.message?.content;
    if (!content) throw new Error("Empty response from Pollinations");
    return content;
  }
  if (cfg.provider === "ollama") {
    const data = await fetchJson(`${url}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders(cfg) },
      body: JSON.stringify({
        model: cfg.model,
        messages,
        stream: false,
        options: {
          temperature: opts.temperature ?? 0.4,
          num_predict: opts.maxTokens ?? 400,
        },
      }),
    }, 120000);
    const content = (data as { message?: { content?: string } }).message
      ?.content;
    if (!content) throw new Error("Empty response from Ollama");
    return content;
  }
  const body = JSON.stringify({
    model: cfg.model || "local-model",
    messages: messages.map((m) =>
      m.images?.length && m.contentParts
        ? { role: m.role, content: m.contentParts }
        : m,
    ),
    temperature: opts.temperature ?? 0.4,
    max_tokens: opts.maxTokens ?? 400,
    stream: false,
  });
  const headers = { "Content-Type": "application/json", ...authHeaders(cfg) };
  // Gateways disagree on the /v1 prefix — try with it, then without.
  let data: unknown;
  try {
    data = await fetchJson(`${apiBase(url)}/v1/chat/completions`, {
      method: "POST",
      headers,
      body,
    }, 120000);
  } catch (e) {
    if (!(e instanceof Error && /HTTP 40[40]/.test(e.message))) throw e;
    data = await fetchJson(`${normalizeUrl(url)}/chat/completions`, {
      method: "POST",
      headers,
      body,
    }, 120000);
  }
  const content = (data as {
    choices?: { message?: { content?: string } }[];
  }).choices?.[0]?.message?.content;
  if (!content) throw new Error("Empty response from local model");
  return content;
}

export interface VisionTarget {
  description: string;
  x: number;
  y: number;
}

/**
 * Ask the vision model to locate something on a screenshot.
 * Uses Ollama's image input (base64) or the OpenAI-compatible image_url part.
 * Returns the target's pixel coordinates (scaled to full screen size).
 */
export async function visionLocate(
  cfg: LlmConfig,
  imageDataUri: string,
  screenW: number,
  screenH: number,
  description: string,
): Promise<{ target?: VisionTarget; raw?: string; error?: string }> {
  const vision = cfg.visionModel?.trim() || cfg.model;
  const url = cfg.provider === "pollinations" ? normalizeUrl(cfg.url) : apiBase(cfg.url);
  const chatPath = cfg.provider === "pollinations" ? "/openai" : "/v1/chat/completions";
  const instr = `You are the vision system of a computer-control assistant. Locate: "${description}".
The image is a full screenshot, ${screenW}x${screenH} pixels.
Reply with ONLY a JSON object, nothing else:
{"x":<center x of the target>,"y":<center y of the target>,"description":"<what you found>"}
If the target is not visible, reply with {"notfound":true}`;
  try {
    let reply: string;
    if (cfg.provider === "ollama") {
      const b64 = imageDataUri.replace(/^data:[^,]+,/, "");
      const data = await fetchJson(
        `${url}/api/chat`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: vision,
            messages: [{ role: "user", content: instr, images: [b64] }],
            stream: false,
            options: { temperature: 0, num_predict: 120 },
          }),
        },
        120000,
      );
      reply = (data as { message?: { content?: string } }).message?.content ?? "";
    } else {
      const data = await fetchJson(
        `${url}${chatPath}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", ...authHeaders(cfg) },
          body: JSON.stringify({
            model: vision,
            messages: [
              {
                role: "user",
                content: [
                  { type: "text", text: instr },
                  { type: "image_url", image_url: { url: imageDataUri } },
                ],
              },
            ],
            max_tokens: 120,
            stream: false,
          }),
        },
        120000,
      );
      reply =
        (data as { choices?: { message?: { content?: string } }[] })
          .choices?.[0]?.message?.content ?? "";
    }
    const fenced = reply.match(/```(?:json)?\s*([\s\S]*?)```/);
    const candidate = (fenced ? fenced[1] : reply).trim();
    const start = candidate.indexOf("{");
    const end = candidate.lastIndexOf("}");
    if (start === -1 || end === -1) return { raw: reply, error: "No JSON in vision reply." };
    const obj = JSON.parse(candidate.slice(start, end + 1)) as {
      x?: number;
      y?: number;
      description?: string;
      notfound?: boolean;
    };
    if (obj.notfound || typeof obj.x !== "number" || typeof obj.y !== "number") {
      return { raw: reply, error: `I couldn't find "${description}" on screen.` };
    }
    // Model may answer in a 0-1000 normalized space — scale if clearly out of bounds.
    let x = obj.x;
    let y = obj.y;
    if (x > screenW || y > screenH) {
      x = Math.round((x / 1000) * screenW);
      y = Math.round((y / 1000) * screenH);
    }
    return {
      target: {
        x: Math.max(0, Math.min(screenW - 1, Math.round(x))),
        y: Math.max(0, Math.min(screenH - 1, Math.round(y))),
        description: obj.description ?? description,
      },
      raw: reply,
    };
  } catch (e) {
    return {
      error: e instanceof Error ? e.message : "Vision request failed.",
    };
  }
}

/** Ask the model to return a point sequence (a stroke) for drawing tasks. */
export async function visionPath(
  cfg: LlmConfig,
  imageDataUri: string,
  screenW: number,
  screenH: number,
  description: string,
): Promise<{ points?: { x: number; y: number }[]; error?: string }> {
  const vision = cfg.visionModel?.trim() || cfg.model;
  const url = cfg.provider === "pollinations" ? normalizeUrl(cfg.url) : apiBase(cfg.url);
  const chatPath = cfg.provider === "pollinations" ? "/openai" : "/v1/chat/completions";
  const instr = `You control a mouse to draw on screen. Task: ${description}
The image is a screenshot, ${screenW}x${screenH} pixels.
Reply with ONLY JSON: {"points":[{"x":..,"y":..}, ...]} — 8 to 40 points tracing the desired stroke, full-screen pixel coordinates.
If the request is unclear, reply {"notfound":true}`;
  try {
    let reply: string;
    if (cfg.provider === "ollama") {
      const b64 = imageDataUri.replace(/^data:[^,]+,/, "");
      const data = await fetchJson(
        `${url}/api/chat`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model: vision,
            messages: [{ role: "user", content: instr, images: [b64] }],
            stream: false,
            options: { temperature: 0.2, num_predict: 800 },
          }),
        },
        120000,
      );
      reply = (data as { message?: { content?: string } }).message?.content ?? "";
    } else {
      const data = await fetchJson(
        `${url}${chatPath}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", ...authHeaders(cfg) },
          body: JSON.stringify({
            model: vision,
            messages: [
              {
                role: "user",
                content: [
                  { type: "text", text: instr },
                  { type: "image_url", image_url: { url: imageDataUri } },
                ],
              },
            ],
            max_tokens: 800,
            stream: false,
          }),
        },
        120000,
      );
      reply =
        (data as { choices?: { message?: { content?: string } }[] })
          .choices?.[0]?.message?.content ?? "";
    }
    const fenced = reply.match(/```(?:json)?\s*([\s\S]*?)```/);
    const candidate = (fenced ? fenced[1] : reply).trim();
    const start = candidate.indexOf("{");
    const end = candidate.lastIndexOf("}");
    if (start === -1 || end === -1) return { error: "No JSON in vision reply." };
    const obj = JSON.parse(candidate.slice(start, end + 1)) as {
      points?: { x: number; y: number }[];
      notfound?: boolean;
    };
    if (obj.notfound || !Array.isArray(obj.points) || obj.points.length < 2) {
      return { error: `I couldn't work out a path for "${description}".` };
    }
    const pts = obj.points
      .filter((p) => typeof p?.x === "number" && typeof p?.y === "number")
      .map((p) => {
        let x = p.x;
        let y = p.y;
        if (x > screenW || y > screenH) {
          x = (x / 1000) * screenW;
          y = (y / 1000) * screenH;
        }
        return {
          x: Math.max(0, Math.min(screenW - 1, Math.round(x))),
          y: Math.max(0, Math.min(screenH - 1, Math.round(y))),
        };
      });
    if (pts.length < 2) return { error: "Vision returned too few points." };
    return { points: pts };
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Vision request failed." };
  }
}
export async function planToolCall(
  cfg: LlmConfig,
  userMessage: string,
  tools: ToolSpec[],
): Promise<{ tool: string; args: Record<string, unknown> } | null> {
  const spec = tools
    .map(
      (t) =>
        `- ${t.id}: ${t.description}${t.args ? ` (args JSON: ${t.args})` : " (args: {})"}`,
    )
    .join("\n");
  const prompt = SYSTEM_PROMPT.replace("{TOOLS}", spec).replace(
    "{MEMORY}",
    memoryPromptBlock(),
  );
  const reply = await llmChat(cfg, [
    { role: "system", content: prompt },
    { role: "user", content: userMessage },
  ], { temperature: 0, maxTokens: 200 });
  return parseToolCall(reply);
}

/** Parse a {"tool":...,"args":...} JSON object out of a model reply. */
export function parseToolCall(
  reply: string,
): { tool: string; args: Record<string, unknown> } | null {
  const fenced = reply.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = (fenced ? fenced[1] : reply).trim();
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    const obj = JSON.parse(candidate.slice(start, end + 1)) as {
      tool?: unknown;
      args?: unknown;
    };
    if (typeof obj.tool !== "string") return null;
    return {
      tool: obj.tool,
      args:
        obj.args && typeof obj.args === "object"
          ? (obj.args as Record<string, unknown>)
          : {},
    };
  } catch {
    return null;
  }
}
